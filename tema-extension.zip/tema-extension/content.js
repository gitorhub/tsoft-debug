document.addEventListener("DOMContentLoaded", () => {
    document.documentElement.setAttribute("data-tsoft-devtools", "installed");
});
